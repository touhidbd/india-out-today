# India Out Today
 India Out Today is a WordPress plugin that helps users boycott products and find alternative options.

# Installation
- Upload ‘india-out-today’ folder to the ‘/wp-content/plugins/’ directory.
- Activate the plugin through the ‘Plugins’ menu in WordPress.

# Shortcode: 
- Place this shortcode anywhere on your page
**[IndiaOutToday]**

# API Provider
[indiaout.today](https://indiaout.today)
